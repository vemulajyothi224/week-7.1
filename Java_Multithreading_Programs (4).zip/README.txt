Java Multithreading Programs

1. ThreadMethod.java: extends the Thread class.
2. RunnableMethod.java: implements the Runnable interface.

Compile and run Method 1:
javac ThreadMethod.java
java ThreadMethod

Compile and run Method 2:
javac RunnableMethod.java
java RunnableMethod

Both programs print messages indefinitely, as required. Stop with Ctrl+C.
The order of messages may differ because threads run concurrently.
